# Setting up monitoring of suspicious clients and server IPs for a Kubernetes cluster

To try out the Security Advisor network analysis feature, install the Security Advisor components in a Kubernetes cluster that is deployed to {{site.data.keyword.containerlong_notm}}. Then, you can see network insights and alerts in the Security Advisor dashboard.

> **Note:** This feature of Security Advisor is a technology preview.

## Prerequisites

Before you begin:

* Mac, Linux or Windows 10 developer workstation
  * Windows 10: [enable the Linux Subsystem feature](https://win10faq.com/install-run-ubuntu-bash-windows-10/)
* [Node.js](https://nodejs.org/en/) 6 or above
* [jQ](https://stedolan.github.io/jq/download/)
* [IBM Cloud Command Line Interface](https://console.bluemix.net/docs/cli/reference/bluemix_cli/get_started.html#getting-started) v0.6.5 or above
* [IBM Cloud Container Service CLI plug-in](https://console.bluemix.net/docs/containers/cs_cli_install.html#cs_cli_install)
* [Kubernetes CLI (kubectl)](https://kubernetes.io/docs/tasks/tools/install-kubectl/) v1.7 or above
* [Kubernetes Helm (package manager)](https://docs.helm.sh/using_helm/#from-script)
* [A free or standard Kubernetes cluster](https://console.bluemix.net/containers-kubernetes/catalog/cluster) in the **US South** region of IBM Cloud
* Identify the IBM Cloud account owner to complete the installation steps
* Update the ibmcloud cli using `ibmcloud update`
* Update the ibmcloud container service plugin using `ibmcloud plugin update container-service`

## Logging in to your cluster

1.  Log in to IBM Cloud.

    ```
    ibmcloud login -a https://api.ng.bluemix.net --sso
    ```

2.  List all of the clusters in the account to get the name of the cluster.

    ```
    ibmcloud ks clusters
    ```

3.  Target your CLI to the cluster.

    ```
    ibmcloud ks cluster-config <cluster-name-or-id>
    ```

4.  Set the path to the local Kubernetes configuration file as an environment variable. Example:

    ```
    export KUBECONFIG=/Users/<user_name>/.bluemix/plugins/container-service/clusters/<cluster_name>/kube-config-prod-dal10-<cluster_name>.yml
    ```    

5.  Set up Helm in the cluster.

    ```
    helm init
    ```  

> **Note:** Keep this command line window open and continue.

## Installing Security Advisor components

> **Note:** The installer must be executed by the IBM Cloud account owner.

When you set up Security Advisor, the following actions take place:
1. Cluster metadata is collected and used to complete the installation of worker node IP addresses, subnets, Ingress URL and IP address, cluster CRN, Log Analysis endpoint, space, and token.
2. An IAM service ID and API key are generated in your IBM Cloud account so that your cluster can be identified by Security Advisor. If you have more than one cluster, run the installation for each cluster to generate service IDs and API keys for each cluster.
3. The Security Advisor components are deployed in the **monitoring** namespace in your cluster.

To install the Security Advisor components:

1.  From the same command line window as the previous section, navigate to the extracted archive location and install the package.

    ```
    ./install.sh
    ```

2.  Verify that the components are installed properly by checking the [Security Advisor dashboard](https://console.bluemix.net/security/advisor/#!/dashboard).

## Removing Security Advisor components from your Kubernetes cluster

Remove the Security Advisor components from your cluster and the service ID and API key from your {{site.data.keyword.Bluemix_notm}} account.

1.  Log in to IBM Cloud.

    ```
    ibmcloud login -a https://api.ng.bluemix.net --sso
    ```

2.  List all of the clusters in the account to get the name of the cluster.

    ```
    ibmcloud ks clusters
    ```

3.  Target your CLI to the cluster.

    ```
    ibmcloud ks cluster-config <cluster-name-or-id>
    ```

4.  Set the path to the local Kubernetes configuration file as an environment variable. Example:

    ```
    export KUBECONFIG=/Users/<user_name>/.bluemix/plugins/container-service/clusters/<cluster_name>/kube-config-prod-dal10-<cluster_name>.yml
    ```

5.  Navigate to the extracted archive location and run the uninstaller script.

    ```
    ./uninstall.sh
    ```


6.  Optional: Uninstall the Helm server component from the cluster.

    ```
    helm reset
    ```

## Troubleshooting
If you are unable to successfully install the IBM Cloud Security Advisor components, or have any other question or feedback in mind, please [open a new thread in the support forum]( https://developer.ibm.com/answers/topics/securityadvisor/). Use the tags "securityadvisor" and "ibmcloud".
